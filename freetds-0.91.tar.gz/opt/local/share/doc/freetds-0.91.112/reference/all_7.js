var searchData=
[
  ['has_5fstatus',['has_status',['../a00122.html#a75ab58b901d242ae27e36bd39b23a54f',1,'tds_socket']]],
  ['hasargs',['hasargs',['../a00096.html#ad2b3362f65d1b6f2b4b6f94513dbcf08',1,'tds_cursor']]],
  ['hour',['hour',['../a00127.html#ae9f0348efe607ac7333eac841be46333',1,'tdsdaterec']]]
];
