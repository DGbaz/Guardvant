var searchData=
[
  ['tds_5fdead',['TDS_DEAD',['../a00162.html#a4fa5fe915f5b796690c577a55dd71a17af087b64970a1fb35bbcf1bc6ea7a643d',1,'tds.h']]],
  ['tds_5fdone_5fcancelled',['TDS_DONE_CANCELLED',['../a00162.html#aa8d8044be84bcde003f28ec25a77519ca202254cfd6784404cf1aa22bc7147c86',1,'tds.h']]],
  ['tds_5fdone_5fcount',['TDS_DONE_COUNT',['../a00162.html#aa8d8044be84bcde003f28ec25a77519caf17d0c6591e318014c806a10c2f0270b',1,'tds.h']]],
  ['tds_5fdone_5ferror',['TDS_DONE_ERROR',['../a00162.html#aa8d8044be84bcde003f28ec25a77519caa9d79a3b62e3321332223ac3d1a5b18d',1,'tds.h']]],
  ['tds_5fdone_5ffinal',['TDS_DONE_FINAL',['../a00162.html#aa8d8044be84bcde003f28ec25a77519ca7ed9046db24ad78bb94c2b12d6e11f46',1,'tds.h']]],
  ['tds_5fdone_5finxact',['TDS_DONE_INXACT',['../a00162.html#aa8d8044be84bcde003f28ec25a77519cac79a30d1a0bac125e77d87f5d87bc2b2',1,'tds.h']]],
  ['tds_5fdone_5fmore_5fresults',['TDS_DONE_MORE_RESULTS',['../a00162.html#aa8d8044be84bcde003f28ec25a77519ca688b8bf555ce6ae72f3e047177bfc966',1,'tds.h']]],
  ['tds_5fdone_5fproc',['TDS_DONE_PROC',['../a00162.html#aa8d8044be84bcde003f28ec25a77519cae170f368306f421d507c6f08e4d48d9a',1,'tds.h']]],
  ['tds_5fdone_5fsrverror',['TDS_DONE_SRVERROR',['../a00162.html#aa8d8044be84bcde003f28ec25a77519ca7bfe89d6f8fc309eae412ad0a503e34c',1,'tds.h']]],
  ['tds_5fidle',['TDS_IDLE',['../a00162.html#a4fa5fe915f5b796690c577a55dd71a17ad1586abc1f75b7f3d640b994afe310e9',1,'tds.h']]],
  ['tds_5fpending',['TDS_PENDING',['../a00162.html#a4fa5fe915f5b796690c577a55dd71a17a00f6d5ac5560f2f44661e599241849a8',1,'tds.h']]],
  ['tds_5fquerying',['TDS_QUERYING',['../a00162.html#a4fa5fe915f5b796690c577a55dd71a17a8450793c640d04e225eebb463cbc85f9',1,'tds.h']]],
  ['tds_5freading',['TDS_READING',['../a00162.html#a4fa5fe915f5b796690c577a55dd71a17a36ddbc8f326d6b297009a8fafd958529',1,'tds.h']]]
];
