var searchData=
[
  ['bcp_5fhostcolinfo',['BCP_HOSTCOLINFO',['../a00045.html',1,'']]],
  ['bcp_5fhostfileinfo',['BCP_HOSTFILEINFO',['../a00046.html',1,'']]]
];
