var searchData=
[
  ['s',['s',['../a00122.html#ad3c941ce75ee41878a99e0ef75092051',1,'tds_socket']]],
  ['second',['second',['../a00127.html#a8560717700de586f279af702bac86ad6',1,'tdsdaterec']]],
  ['server_5fcharset',['server_charset',['../a00094.html#a02ee7abb016629cd09079514ec66765f',1,'tds_connection']]],
  ['server_5fname',['server_name',['../a00094.html#aee4260a5488b31b7b35f0f240f447c27',1,'tds_connection']]],
  ['server_5frealm_5fname',['server_realm_name',['../a00094.html#a50078b860467d553f15249dd7c48f93e',1,'tds_connection']]],
  ['sizes',['sizes',['../a00057.html#abe1aa9f8ea96dda1400654813e68130a',1,'dblib_buffer_row']]],
  ['status',['status',['../a00096.html#ab5d6a587ac5780f001d383d4b874852f',1,'tds_cursor']]],
  ['stmt_5flist',['stmt_list',['../a00034.html#a4a9f3e8f1eba573df79a1ed300d8fc91',1,'_hdbc']]]
];
