var searchData=
[
  ['primary_20functions',['Primary functions',['../a00294.html',1,'']]]
];
