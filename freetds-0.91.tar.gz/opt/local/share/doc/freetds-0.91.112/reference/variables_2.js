var searchData=
[
  ['day',['day',['../a00127.html#a82d0cf263d8d4a3abcf84b9a146ddf83',1,'tdsdaterec']]],
  ['dayofyear',['dayofyear',['../a00127.html#a3f7925156708744d28016aacb90b6093',1,'tdsdaterec']]],
  ['dsn',['dsn',['../a00068.html#acd76726add649629f26f1f1754fe48cf',1,'DSNINFO']]],
  ['dyns',['dyns',['../a00122.html#a3ce2da581aba9192f6162e96741604ce',1,'tds_socket']]]
];
