var searchData=
[
  ['dblib_2ec',['dblib.c',['../a00198.html',1,'']]]
];
