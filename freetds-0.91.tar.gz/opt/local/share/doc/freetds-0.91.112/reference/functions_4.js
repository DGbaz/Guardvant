var searchData=
[
  ['parse_5fserver_5fname_5ffor_5fport',['parse_server_name_for_port',['../a00305.html#gaf19ef62b462f3fb2481244580d112883',1,'config.c']]]
];
