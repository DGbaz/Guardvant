var searchData=
[
  ['bulk_20copy_20functions',['Bulk copy functions',['../a00296.html',1,'']]]
];
