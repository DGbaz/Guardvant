var searchData=
[
  ['odbc_20api',['ODBC API',['../a00302.html',1,'']]],
  ['odbc_5fc_5fto_5fserver_5ftype',['odbc_c_to_server_type',['../a00303.html#gafc3593e71189aa4f32a6f6f42dc7cfd7',1,'odbc_c_to_server_type(int c_type):&#160;odbc_util.c'],['../a00303.html#gafc3593e71189aa4f32a6f6f42dc7cfd7',1,'odbc_c_to_server_type(int c_type):&#160;odbc_util.c']]],
  ['odbc_5fget_5fparam_5flen',['odbc_get_param_len',['../a00303.html#ga35028e8de1d50dc51ccef1d645c55e2a',1,'odbc_get_param_len(const struct _drecord *drec_axd, const struct _drecord *drec_ixd, const TDS_DESC *axd, unsigned int n_row):&#160;odbc_util.c'],['../a00303.html#ga35028e8de1d50dc51ccef1d645c55e2a',1,'odbc_get_param_len(const struct _drecord *drec_axd, const struct _drecord *drec_ixd, const TDS_DESC *axd, unsigned int n_row):&#160;odbc_util.c']]],
  ['odbc_5frdbms_5fversion',['odbc_rdbms_version',['../a00303.html#gae85ff7fb2002b5a7abc04fbee79e5525',1,'odbc_rdbms_version(TDSSOCKET *tds, char *pversion_string):&#160;odbc_util.c'],['../a00303.html#gae85ff7fb2002b5a7abc04fbee79e5525',1,'odbc_rdbms_version(TDSSOCKET *tds_socket, char *pversion_string):&#160;odbc_util.c']]],
  ['odbc_5fserver_5fto_5fsql_5ftype',['odbc_server_to_sql_type',['../a00303.html#ga48b785425697ed26acef484aec874c44',1,'odbc_server_to_sql_type(int col_type, int col_size):&#160;odbc_util.c'],['../a00303.html#ga48b785425697ed26acef484aec874c44',1,'odbc_server_to_sql_type(int col_type, int col_size):&#160;odbc_util.c']]],
  ['odbc_5fset_5fconcise_5fc_5ftype',['odbc_set_concise_c_type',['../a00303.html#ga128f6b09cde0af252370ba89cfa1fb78',1,'odbc_set_concise_c_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c'],['../a00303.html#ga128f6b09cde0af252370ba89cfa1fb78',1,'odbc_set_concise_c_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c']]],
  ['odbc_5fset_5fconcise_5fsql_5ftype',['odbc_set_concise_sql_type',['../a00303.html#ga125574bd2de677438909612db80041ea',1,'odbc_set_concise_sql_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c'],['../a00303.html#ga125574bd2de677438909612db80041ea',1,'odbc_set_concise_sql_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c']]],
  ['odbc_5fset_5fstring_5fflag',['odbc_set_string_flag',['../a00303.html#gadba4490bf3183799a70c9e2f44fab331',1,'odbc_set_string_flag(TDS_DBC *dbc, SQLPOINTER buffer, SQLINTEGER cbBuffer, void FAR *pcbBuffer, const char *s, int len, int flag):&#160;odbc_util.c'],['../a00303.html#gadba4490bf3183799a70c9e2f44fab331',1,'odbc_set_string_flag(TDS_DBC *dbc, SQLPOINTER buffer, SQLINTEGER cbBuffer, void FAR *pcbBuffer, const char *s, int len, int flag):&#160;odbc_util.c']]],
  ['odbc_20utility',['ODBC utility',['../a00303.html',1,'']]],
  ['options',['options',['../a00096.html#a1be9f69f84a6d83ce86380c33a2bf9f8',1,'tds_cursor']]],
  ['origdsn',['origdsn',['../a00068.html#a8127a82b8c4130820a4c44f88eda8bcf',1,'DSNINFO']]],
  ['out_5fbuf',['out_buf',['../a00122.html#ad6b5121e435d22d640a645b98833cb9d',1,'tds_socket']]],
  ['out_5fflag',['out_flag',['../a00122.html#a9bb663ee7c71f56f1602cbfcd993018c',1,'tds_socket']]],
  ['out_5fpos',['out_pos',['../a00122.html#a426adbd80f29f477377e42e8f78d3ff0',1,'tds_socket']]]
];
