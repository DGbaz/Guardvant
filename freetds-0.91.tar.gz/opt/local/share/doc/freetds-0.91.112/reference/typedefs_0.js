var searchData=
[
  ['dblib_5ferror_5fmessage',['DBLIB_ERROR_MESSAGE',['../a00300.html#ga73ccf3a130f836159e43074544f338e3',1,'dblib.c']]],
  ['dblibcontext',['DBLIBCONTEXT',['../a00198.html#ac34310fe36604ce96b30f66427b093ef',1,'dblib.c']]]
];
