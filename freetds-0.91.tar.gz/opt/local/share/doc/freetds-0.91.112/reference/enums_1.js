var searchData=
[
  ['tds_5fbcp_5fdirections',['tds_bcp_directions',['../a00162.html#ad5c5c8cb776334af4b0ebf7a0d740cb2',1,'tds.h']]],
  ['tds_5fend',['tds_end',['../a00162.html#aa8d8044be84bcde003f28ec25a77519c',1,'tds.h']]],
  ['tds_5foption_5fcmd',['TDS_OPTION_CMD',['../a00162.html#a113928faf73e15b0e0a70b1026e90320',1,'tds.h']]]
];
